# Aidos Market Desktop Demo

**Made by Aidos Market**

Aidos Market is a branded desktop demo exchange for Windows. It provides a polished trading simulation that users can share, launch locally, and test with no real funds.

## Branding included
- App name: **Aidos Market**
- Installer name: **Aidos Market Setup**
- Version: **v1.0.0**
- Custom Aidos logo icon for the Windows app and installer
- Splash animation with Aidos Market branding
- No third-party product branding in the app copy

## Supported assets and pairs
Assets in the demo:
- BTC
- USDT
- USDC
- ETH
- ADK

Trading pairs:
- BTC/USDT
- BTC/USDC
- ETH/BTC
- ADK/BTC

## Included demo features
- Splash screen with animated Aidos logo
- Demo login accounts
- Candlestick-style market chart
- Simulated market movement
- Simulated order book and trade feed
- Buy and sell order simulation
- Profit and loss tracking
- Fake network activity and relay status
- Resettable demo balances

## Demo accounts
- `demo` / `demo123`
- `tester` / `market123`

## How to run locally
1. Extract the zip.
2. Open a terminal in the project folder.
3. Install dependencies:

```bash
npm install
```

4. Start the desktop demo in development mode:

```bash
npm run electron:dev
```

## How to build the Windows EXE
Run:

```bash
npm install
npm run dist
```

The generated Windows builds will be placed in:

```text
dist-electron/
```

Expected output names include:
- `Aidos Market Setup 1.0.0.exe`
- `Aidos Market Portable 1.0.0.exe`

## Notes
- This is a simulation-only exchange demo.
- No real wallets, deposits, or blockchain transactions are performed.
- All balances, prices, trades, and network activity are simulated for presentation and user testing.
