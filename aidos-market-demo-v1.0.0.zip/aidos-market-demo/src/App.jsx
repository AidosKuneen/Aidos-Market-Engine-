import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bar, CartesianGrid, Cell, ComposedChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const BRAND = {
  bg: '#073b63',
  panel: '#0b4d7a',
  panel2: '#0f5d93',
  accent: '#16c8c9',
  accentSoft: '#79eef0',
  text: '#f6fbff',
  muted: '#b4d6e8',
  green: '#21d88f',
  red: '#ff6b7a',
  line: 'rgba(255,255,255,0.10)'
};

const MARKETS = {
  'BTC/USDT': { base: 'BTC', quote: 'USDT', price: 64250.0 },
  'BTC/USDC': { base: 'BTC', quote: 'USDC', price: 64220.0 },
  'ETH/BTC': { base: 'ETH', quote: 'BTC', price: 0.0496 },
  'ADK/BTC': { base: 'ADK', quote: 'BTC', price: 0.0000068 }
};

const LOGIN_USERS = [
  { username: 'demo', password: 'demo123' },
  { username: 'tester', password: 'market123' }
];

const fmt = (n, d = 2) => new Intl.NumberFormat('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }).format(Number(n || 0));
const money = (n) => `$${fmt(n, n < 1 ? 4 : 2)}`;
const id = () => Math.random().toString(36).slice(2, 10);

function buildCandles(seed, precise = false) {
  const out = [];
  let prev = seed;
  for (let i = 0; i < 32; i += 1) {
    const open = prev;
    const drift = (Math.random() - 0.48) * seed * (precise ? 0.012 : 0.018);
    const close = Math.max(0.0000001, open + drift);
    const high = Math.max(open, close) + Math.random() * seed * 0.004;
    const low = Math.min(open, close) - Math.random() * seed * 0.004;
    out.push({
      time: `${String(i).padStart(2, '0')}:00`,
      open: Number(open.toFixed(precise ? 7 : 2)),
      close: Number(close.toFixed(precise ? 7 : 2)),
      high: Number(high.toFixed(precise ? 7 : 2)),
      low: Number(Math.max(0.0000001, low).toFixed(precise ? 7 : 2)),
      wickTop: Number((Math.max(open, close) - Math.min(open, close)).toFixed(precise ? 7 : 2)),
      bodyBottom: Number(Math.min(open, close).toFixed(precise ? 7 : 2)),
      isUp: close >= open,
    });
    prev = close;
  }
  return out;
}

function buildBook(mid, precise = false) {
  return {
    bids: Array.from({ length: 8 }).map((_, i) => ({
      id: id(),
      price: Number((mid - (i + 1) * mid * 0.0012).toFixed(precise ? 7 : 2)),
      amount: Number((Math.random() * 1.75 + 0.08).toFixed(4))
    })),
    asks: Array.from({ length: 8 }).map((_, i) => ({
      id: id(),
      price: Number((mid + (i + 1) * mid * 0.0012).toFixed(precise ? 7 : 2)),
      amount: Number((Math.random() * 1.75 + 0.08).toFixed(4))
    }))
  };
}

function pairDecimals(pair) {
  return pair === 'ETH/BTC' ? 5 : pair === 'ADK/BTC' ? 7 : 2;
}

function priceLabel(pair, price) {
  const d = pairDecimals(pair);
  const quote = MARKETS[pair].quote;
  return quote === 'BTC' ? `${fmt(price, d)} BTC` : `${fmt(price, d)} ${quote}`;
}

function usdValue(asset, amount, priceMap) {
  if (asset === 'USDT' || asset === 'USDC') return amount;
  if (asset === 'BTC') return amount * priceMap['BTC/USDT'];
  if (asset === 'ETH') return amount * priceMap['ETH/BTC'] * priceMap['BTC/USDT'];
  if (asset === 'ADK') return amount * priceMap['ADK/BTC'] * priceMap['BTC/USDT'];
  return 0;
}

function Splash({ onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2200);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="splash-root">
      <motion.div initial={{ scale: 0.86, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.6 }} className="splash-card">
        <motion.div initial={{ opacity: 0.1 }} animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 2.2 }} className="logo-ring" />
        <motion.img
          src="/aidos-logo.png"
          alt="Aidos Market logo"
          className="brand-logo splash-logo"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
        />
        <div className="brand-title">AIDOS <span>MARKET</span></div>
        <div className="brand-sub">Made by Aidos Market · desktop demo exchange</div>
        <div className="loader"><span /></div>
      </motion.div>
    </div>
  );
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('demo');
  const [password, setPassword] = useState('demo123');
  const [error, setError] = useState('');

  function submit(e) {
    e.preventDefault();
    const ok = LOGIN_USERS.find((u) => u.username === username && u.password === password);
    if (!ok) {
      setError('Invalid demo credentials');
      return;
    }
    onLogin(username);
  }

  return (
    <div className="login-root">
      <div className="login-panel">
        <img src="/aidos-logo.png" alt="Aidos Market logo" className="brand-logo login-logo" />
        <div className="brand-title large">AIDOS <span>MARKET</span></div>
        <p className="login-sub">Demo login for the Aidos Market Windows app</p>
        <form onSubmit={submit} className="login-form">
          <label>
            Username
            <input value={username} onChange={(e) => setUsername(e.target.value)} />
          </label>
          <label>
            Password
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>
          {error ? <div className="error-box">{error}</div> : null}
          <button type="submit">Enter Demo</button>
        </form>
        <div className="login-credentials">Demo accounts: <b>demo / demo123</b> or <b>tester / market123</b></div>
      </div>
    </div>
  );
}

export default function App() {
  const [phase, setPhase] = useState('splash');
  const [user, setUser] = useState('');
  const [pair, setPair] = useState('BTC/USDT');
  const [side, setSide] = useState('buy');
  const [orderType, setOrderType] = useState('market');
  const [amount, setAmount] = useState('0.01');
  const [limitPrice, setLimitPrice] = useState(String(MARKETS['BTC/USDT'].price));
  const [marketPrice, setMarketPrice] = useState(MARKETS['BTC/USDT'].price);
  const [candles, setCandles] = useState(buildCandles(MARKETS['BTC/USDT'].price));
  const [book, setBook] = useState(buildBook(MARKETS['BTC/USDT'].price));
  const [notice, setNotice] = useState('Aidos network synchronized · simulation active');
  const [balances, setBalances] = useState({ BTC: 0.4, USDT: 10000, USDC: 10000, ETH: 12, ADK: 500000 });
  const [orders, setOrders] = useState([]);
  const [trades, setTrades] = useState([]);
  const [network, setNetwork] = useState({ peers: 8, latency: 44, status: 'LIVE (simulated)' });
  const [priceMap, setPriceMap] = useState({
    'BTC/USDT': MARKETS['BTC/USDT'].price,
    'BTC/USDC': MARKETS['BTC/USDC'].price,
    'ETH/BTC': MARKETS['ETH/BTC'].price,
    'ADK/BTC': MARKETS['ADK/BTC'].price,
  });

  const meta = MARKETS[pair];
  const precise = meta.quote === 'BTC';

  useEffect(() => {
    const seed = priceMap[pair] || MARKETS[pair].price;
    setMarketPrice(seed);
    setLimitPrice(String(seed));
    setCandles(buildCandles(seed, precise));
    setBook(buildBook(seed, precise));
  }, [pair, precise]);

  useEffect(() => {
    if (phase !== 'app') return undefined;
    const timer = setInterval(() => {
      setPriceMap((old) => {
        const nextMap = { ...old };
        Object.keys(MARKETS).forEach((m) => {
          const current = nextMap[m];
          const isPrecise = MARKETS[m].quote === 'BTC';
          const multiplier = m === pair ? (isPrecise ? 0.012 : 0.0035) : (isPrecise ? 0.005 : 0.0015);
          const next = Math.max(0.0000001, current + (Math.random() - 0.5) * current * multiplier);
          nextMap[m] = Number(next.toFixed(pairDecimals(m)));
        });
        const active = nextMap[pair];
        setMarketPrice(active);
        setCandles((oldCandles) => {
          const rest = oldCandles.slice(1);
          const prior = oldCandles[oldCandles.length - 1]?.close ?? active;
          const open = prior;
          const close = active;
          const high = Math.max(open, close) + Math.random() * active * 0.003;
          const low = Math.min(open, close) - Math.random() * active * 0.003;
          return [...rest, {
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            open: Number(open.toFixed(pairDecimals(pair))),
            close: Number(close.toFixed(pairDecimals(pair))),
            high: Number(high.toFixed(pairDecimals(pair))),
            low: Number(Math.max(0.0000001, low).toFixed(pairDecimals(pair))),
            wickTop: Number((Math.max(open, close) - Math.min(open, close)).toFixed(pairDecimals(pair))),
            bodyBottom: Number(Math.min(open, close).toFixed(pairDecimals(pair))),
            isUp: close >= open,
          }];
        });
        setBook(buildBook(active, precise));
        setTrades((oldTrades) => [{
          id: id(),
          pair,
          side: Math.random() > 0.5 ? 'buy' : 'sell',
          price: active,
          amount: Number((Math.random() * 1.2 + 0.01).toFixed(4)),
          time: new Date().toLocaleTimeString(),
        }, ...oldTrades].slice(0, 14));
        setNetwork({
          peers: 7 + Math.floor(Math.random() * 6),
          latency: 28 + Math.floor(Math.random() * 40),
          status: 'LIVE (simulated)'
        });
        return nextMap;
      });
    }, 2200);

    return () => clearInterval(timer);
  }, [phase, pair, precise]);

  useEffect(() => {
    if (!notice) return undefined;
    const t = setTimeout(() => setNotice(''), 2800);
    return () => clearTimeout(t);
  }, [notice]);

  const totalUsd = useMemo(() => {
    return Object.entries(balances).reduce((sum, [asset, amount]) => sum + usdValue(asset, amount, priceMap), 0);
  }, [balances, priceMap]);

  const startingUsd = useMemo(() => {
    const initial = { BTC: 0.4, USDT: 10000, USDC: 10000, ETH: 12, ADK: 500000 };
    return Object.entries(initial).reduce((sum, [asset, amount]) => sum + usdValue(asset, amount, MARKETS), 0);
  }, []);

  const pnl = useMemo(() => totalUsd - startingUsd, [totalUsd, startingUsd]);
  const estimated = useMemo(() => Number(amount || 0) * (orderType === 'market' ? marketPrice : Number(limitPrice || 0)), [amount, orderType, marketPrice, limitPrice]);

  function placeOrder() {
    const qty = Number(amount);
    const px = orderType === 'market' ? marketPrice : Number(limitPrice);
    if (!qty || qty <= 0 || !px || px <= 0) {
      setNotice('Enter a valid trade amount and price');
      return;
    }

    const cost = qty * px;
    const { base, quote } = meta;

    if (side === 'buy') {
      if ((balances[quote] || 0) < cost) {
        setNotice(`Insufficient ${quote} balance`);
        return;
      }
      setBalances((b) => ({ ...b, [quote]: b[quote] - cost, [base]: (b[base] || 0) + qty }));
    } else {
      if ((balances[base] || 0) < qty) {
        setNotice(`Insufficient ${base} balance`);
        return;
      }
      setBalances((b) => ({ ...b, [base]: b[base] - qty, [quote]: (b[quote] || 0) + cost }));
    }

    const order = {
      id: id(),
      pair,
      side,
      type: orderType,
      amount: qty,
      price: px,
      total: cost,
      status: orderType === 'market' ? 'filled' : 'simulated-open',
      time: new Date().toLocaleTimeString()
    };
    setOrders((old) => [order, ...old].slice(0, 12));
    setTrades((old) => [{ id: id(), pair, side, price: px, amount: qty, time: new Date().toLocaleTimeString() }, ...old].slice(0, 14));
    setNotice(`${side === 'buy' ? 'Buy' : 'Sell'} order simulated on ${pair}`);
  }

  function resetDemo() {
    setBalances({ BTC: 0.4, USDT: 10000, USDC: 10000, ETH: 12, ADK: 500000 });
    setOrders([]);
    setTrades([]);
    setPair('BTC/USDT');
    setSide('buy');
    setOrderType('market');
    setAmount('0.01');
    setLimitPrice(String(MARKETS['BTC/USDT'].price));
    setPriceMap({
      'BTC/USDT': MARKETS['BTC/USDT'].price,
      'BTC/USDC': MARKETS['BTC/USDC'].price,
      'ETH/BTC': MARKETS['ETH/BTC'].price,
      'ADK/BTC': MARKETS['ADK/BTC'].price,
    });
    setCandles(buildCandles(MARKETS['BTC/USDT'].price));
    setBook(buildBook(MARKETS['BTC/USDT'].price));
    setNotice('Demo balances reset');
  }

  if (phase === 'splash') return <Splash onDone={() => setPhase('login')} />;
  if (phase === 'login') return <Login onLogin={(u) => { setUser(u); setPhase('app'); }} />;

  return (
    <div className="app-shell">
      <div className="topbar glass">
        <div className="brand-wrap">
          <img src="/aidos-logo.png" alt="Aidos Market logo" className="brand-logo topbar-logo" />
          <div>
            <div className="brand-title">AIDOS <span>MARKET</span></div>
            <div className="tiny">Made by Aidos Market · Windows desktop demo · user: {user}</div>
          </div>
        </div>
        <div className="topbar-actions">
          <div className="pill">Pairs: BTC/USDT · BTC/USDC · ETH/BTC · ADK/BTC</div>
          <button className="primary-btn" onClick={resetDemo}>Reset Demo</button>
        </div>
      </div>

      <AnimatePresence>{notice ? <motion.div initial={{ y: -8, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ opacity: 0 }} className="notice glass">{notice}</motion.div> : null}</AnimatePresence>

      <div className="stats-grid">
        <div className="stat glass"><span>Total Equity</span><b>{money(totalUsd)}</b></div>
        <div className="stat glass"><span>PnL</span><b style={{ color: pnl >= 0 ? BRAND.green : BRAND.red }}>{money(pnl)}</b></div>
        <div className="stat glass"><span>Active Pair</span><b>{pair}</b></div>
        <div className="stat glass"><span>Last Price</span><b>{priceLabel(pair, marketPrice)}</b></div>
      </div>

      <div className="content-grid">
        <div className="left-stack">
          <div className="panel glass">
            <div className="panel-head">
              <div>
                <h3>Market</h3>
                <p>Binance-style candlestick view with Aidos branding</p>
              </div>
              <div className="pair-select-wrap">
                <select value={pair} onChange={(e) => setPair(e.target.value)}>
                  {Object.keys(MARKETS).map((m) => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>
            <div className="candles-wrap">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={candles}>
                  <CartesianGrid stroke={BRAND.line} vertical={false} />
                  <XAxis dataKey="time" tick={{ fill: BRAND.muted, fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fill: BRAND.muted, fontSize: 11 }} tickLine={false} axisLine={false} domain={["auto", "auto"]} />
                  <Tooltip contentStyle={{ background: BRAND.panel, border: '1px solid rgba(255,255,255,0.10)', borderRadius: 16, color: BRAND.text }} />
                  <Bar dataKey="low" stackId="a" fill="rgba(0,0,0,0)">{candles.map((entry) => <Cell key={entry.time} fill="rgba(0,0,0,0)" />)}</Bar>
                  <Bar dataKey="high" stackId="a" barSize={2}>{candles.map((entry) => <Cell key={`${entry.time}-high`} fill={entry.isUp ? BRAND.green : BRAND.red} />)}</Bar>
                  <Bar dataKey="bodyBottom" stackId="b" fill="rgba(0,0,0,0)">{candles.map((entry) => <Cell key={`${entry.time}-body`} fill="rgba(0,0,0,0)" />)}</Bar>
                  <Bar dataKey="wickTop" stackId="b" barSize={10} radius={[2, 2, 2, 2]}>{candles.map((entry) => <Cell key={`${entry.time}-wick`} fill={entry.isUp ? BRAND.green : BRAND.red} />)}</Bar>
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="dual-grid">
            <div className="panel glass">
              <div className="panel-head simple"><h3>Order Book</h3></div>
              <div className="book-grid">
                <div>
                  <div className="book-title buy">Bids</div>
                  {book.bids.map((row) => <div className="book-row" key={row.id}><span className="buy">{fmt(row.price, pairDecimals(pair))}</span><span>{fmt(row.amount, 4)}</span></div>)}
                </div>
                <div>
                  <div className="book-title sell">Asks</div>
                  {book.asks.map((row) => <div className="book-row" key={row.id}><span className="sell">{fmt(row.price, pairDecimals(pair))}</span><span>{fmt(row.amount, 4)}</span></div>)}
                </div>
              </div>
            </div>
            <div className="panel glass">
              <div className="panel-head simple"><h3>Recent Trades</h3></div>
              <div className="trades-list">
                {trades.map((t) => <div className="trade-row" key={t.id}><span>{t.pair}</span><span className={t.side === 'buy' ? 'buy' : 'sell'}>{t.side.toUpperCase()}</span><span>{fmt(t.price, pairDecimals(t.pair))}</span><span>{fmt(t.amount, 4)}</span></div>)}
              </div>
            </div>
          </div>
        </div>

        <div className="right-stack">
          <div className="panel glass">
            <div className="panel-head simple"><h3>Trade Ticket</h3></div>
            <div className="seg-row">
              <button className={side === 'buy' ? 'seg active buy-bg' : 'seg'} onClick={() => setSide('buy')}>Buy</button>
              <button className={side === 'sell' ? 'seg active sell-bg' : 'seg'} onClick={() => setSide('sell')}>Sell</button>
            </div>
            <div className="seg-row small">
              <button className={orderType === 'market' ? 'seg active cyan-bg' : 'seg'} onClick={() => setOrderType('market')}>Market</button>
              <button className={orderType === 'limit' ? 'seg active cyan-bg' : 'seg'} onClick={() => setOrderType('limit')}>Limit</button>
            </div>
            <label className="field">
              <span>Amount ({meta.base})</span>
              <input value={amount} onChange={(e) => setAmount(e.target.value)} />
            </label>
            <label className="field">
              <span>Price ({meta.quote})</span>
              <input value={limitPrice} onChange={(e) => setLimitPrice(e.target.value)} disabled={orderType === 'market'} />
            </label>
            <div className="summary-box">
              <div><span>Estimated total</span><b>{priceLabel(pair, estimated)}</b></div>
              <div><span>Status</span><b>Simulation only</b></div>
            </div>
            <button className={side === 'buy' ? 'submit-btn buy-bg' : 'submit-btn sell-bg'} onClick={placeOrder}>{side === 'buy' ? 'Simulate Buy' : 'Simulate Sell'}</button>
          </div>

          <div className="panel glass">
            <div className="panel-head simple"><h3>Balances</h3></div>
            {Object.entries(balances).map(([asset, val]) => <div className="balance-row" key={asset}><span>{asset}</span><b>{asset === 'USDT' || asset === 'USDC' ? fmt(val, 2) : fmt(val, asset === 'ADK' ? 0 : 4)}</b></div>)}
          </div>

          <div className="panel glass">
            <div className="panel-head simple"><h3>Network Activity</h3></div>
            <div className="network-item"><span>Gateway</span><b>{network.status}</b></div>
            <div className="network-item"><span>Peers</span><b>{network.peers}</b></div>
            <div className="network-item"><span>Latency</span><b>{network.latency} ms</b></div>
            <div className="network-item"><span>Routing</span><b>Aidos relay mesh</b></div>
          </div>
        </div>
      </div>

      <div className="panel glass bottom-panel">
        <div className="panel-head simple"><h3>Orders</h3></div>
        <div className="orders-table">
          <div className="orders-head"><span>Pair</span><span>Side</span><span>Type</span><span>Amount</span><span>Price</span><span>Total</span><span>Status</span></div>
          {orders.length === 0 ? <div className="orders-empty">No simulated orders yet.</div> : orders.map((o) => <div className="orders-row" key={o.id}><span>{o.pair}</span><span className={o.side === 'buy' ? 'buy' : 'sell'}>{o.side.toUpperCase()}</span><span>{o.type.toUpperCase()}</span><span>{fmt(o.amount, 4)}</span><span>{fmt(o.price, pairDecimals(o.pair))}</span><span>{fmt(o.total, pairDecimals(o.pair))}</span><span>{o.status}</span></div>)}
        </div>
      </div>
    </div>
  );
}
